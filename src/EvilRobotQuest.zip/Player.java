
public class Player extends Person
{
	private String name;
	private String race;
	private String designation;
	private int level;
	private int exp;
	private int health;
	private int maxHealth;
	private int cash;
	private int str;
	private int intl;
	private int dex;
	private int x;
	private int y;
	
	public Player(String name, int maxHealth, int cash, int x, int y, int str, int intl, int dex, String race, String designation)
	{
		super(name, maxHealth, cash, x, y);
		this.race = race;
		this.designation = designation;
		this.level = 0;
		this.exp = 0;
		
		this.str = str;
		this.intl = intl;
		this.dex = dex;
		
		this.x = x;
		this.y = y;
		
		if(race.toUpperCase() == "CYKBOT")
		{
			this.str -= 1;
			this.intl += 2;
		}
		else if(race.toUpperCase() == "TERMIGATER")
		{
			this.dex += 1;
			this.intl -= 1;
			this.str += 1;
		}
		else if(race.toUpperCase() == "ROBOHAMSTER")
		{
			this.dex += 1;
			this.intl -= 1;
			this.str += 1;
		}
		else if(race.toUpperCase() == "DISSECTOR")
		{
			this.dex += 1;
			this.intl -= 1;
			this.str += 1;
		}
		else if(race.toUpperCase() == "DYNAMO")
		{
			this.dex += 1;
			this.intl -= 1;
			this.str += 1;
		}
		else if(race.toUpperCase() == "")
		{
			this.dex += 1;
			this.intl -= 1;
			this.str += 1;
		}
	}
}
