import javax.swing.JFrame;
/** 
 * @author Jonathan Lynn
 * @version 1.0*/

@SuppressWarnings("serial")
public class Game extends JFrame
{	
	public static void main(String[] args)
	{
		Board screen = new Board();
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.addKeyListener(screen);
		frame.add(screen);
		frame.setSize(800, 600);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
	}
}
