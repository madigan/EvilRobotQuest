/** This is a simple Dice simulator. */
import java.util.Random;

public class Dice
{
	private static Random rnd = new Random();
	private Dice()
	{
		//not used.
	}
	public static int roll(int x, int y)
	{
		int retVal = 0;
		for(int i = 0; i < x; i++)
		{
			retVal += rnd.nextInt(y) + 1;
		}
		return retVal;
	}
	public static int roll(String input) //Takes something like "1d6"
	{
		int x = Integer.parseInt(input.split("d")[0]);
		int y = Integer.parseInt(input.split("d")[1]);
		return roll(x, y);
	}
}
