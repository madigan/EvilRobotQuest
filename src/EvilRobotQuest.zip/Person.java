
public class Person
{
	private String name;
	private int health;
	private int maxHealth;
	private int cash;
	private int x;
	private int y;
	
	public Person()
	{
		this.setName("Joe");
		this.setHealth(100);
		this.setMaxHealth(100);
		this.setCash(15);
		this.x = 0;
		this.y = 0;
	}
	public Person(String name, int maxHealth, int cash, int x, int y)
	{
		this.setName(name);
		this.setMaxHealth(maxHealth);
		this.setHealth(maxHealth);
		this.setCash(cash);
		this.x = x;
		this.y = y;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	public String getName()
	{
		return name;
	}
	public void setHealth(int health)
	{
		this.health = health;
	} 
	public int getHealth()
	{
		return health;
	}
	public void setMaxHealth(int maxHealth)
	{
		this.maxHealth = maxHealth;
	}
	public int getMaxHealth()
	{
		return maxHealth;
	}
	public void setCash(int cash)
	{
		this.cash = cash;
	}
	public int getCash()
	{
		return cash;
	}
	
	public void changeHealth(int health)
	{
		if(this.health + health >= this.maxHealth)
		{
			this.health = maxHealth;
		}
		else if(this.health + health <= 0)
		{
			this.health = 0;
		}
		else
		{
			this.health += health;
		}
	}
	public boolean isDead()
	{
		boolean isDead = false;
		if(this.health == 0)
		{
			isDead = true;
		}
		return isDead;
	}
	public String toString()
	{
		String output;
		output = "Name: " + this.name + "\n";
		output += "Health: " + this.health + "/" + this.maxHealth + "\n";
		output += "Cash: " + this.cash + "\n";
		return output;
	}
	/** This checks to see if the location the player wants to move to is
	 * indeed a valid place to move. */
	public void move(int deltaX, int deltaY, int[][] map)
	{
		deltaX += this.getX();
		deltaY += this.getY();
		if(deltaX >= 0 && deltaX < map.length && deltaY >= 0 && deltaY < map.length)
		{
			if(Terrain.isPassable(map[deltaX][deltaY]))
			{
				this.setX(deltaX);
				this.setY(deltaY);
			}
		}
	}
	public void setX(int x)
	{
		this.x = x;
	}
	public int getX()
	{
		return x;
	}
	public void setY(int y)
	{
		this.y = y;
	}
	public int getY()
	{
		return y;
	}
}
