/** @author Jonathan Lynn 
 * This class holds all those terrain properties. In actuality, it
 * is mostly self contained and static. I'm interested to see how it
 * will work.
 * 
 *  The class works by containing and maintaining an array of terrain.
 *  When the game wants to learn something about a tile type, it uses
 *  isPassable or getDefense. These search the array and figures out
 *  which tile, and then retrieves and returns the information. */
public class Terrain
{
	private boolean passable;
	private float defense;
	//private integer movementCost;
	
	//Terrain types
	private static Terrain blank = new Terrain(false, 1);
	private static Terrain grass = new Terrain(true, 1);
	private static Terrain rock = new Terrain(false, 1);
	private static Terrain cliff = new Terrain(false, 1);
	private static Terrain dirt = new Terrain(true, 1);
	private static Terrain forest = new Terrain(true, 1.4f);
	private static Terrain beach = new Terrain(true, 0.8f);
	private static Terrain water = new Terrain(false, 0);
	private static Terrain openedDoor = new Terrain(true, 2);
	private static Terrain closedDoor = new Terrain(false, 1);
	
	//Terrain library
	private static Terrain[] terrainList = {
		grass, grass, rock, cliff, cliff, blank, blank, blank, blank, blank, //Starts at index 0
		blank, blank, blank, cliff, cliff, beach, beach, beach, beach, beach, //Starts at index 10
		beach, beach, beach, blank, blank, blank, blank, blank, blank, blank, //Starts at index 20
		dirt,  dirt,  dirt,  blank, blank, blank, blank, blank, blank, blank, //Starts at index 30
		water, //Starts at index 40
		openedDoor, //Starts at index 50
		closedDoor //Starts at index 60
		};
	
	private Terrain(boolean passable, float defense)
	{
		this.passable = passable;
		if(defense > 0)
		{
			this.defense = defense;
		}
		else
		{
			this.defense = 1;
		}
	}
	
	/** This method figures out whether a tile is passable.
	 * @param id This is the tile's id.
	 * @return Whether the tile can be passed or not. */
	public static boolean isPassable(int id)
	{
		boolean retVal = false;
		if(terrainList[id] != null)
			retVal = terrainList[id].getPassable();
		return retVal;
	}
	
	/** This method figures out whether a tile is passable.
	 * @param id This is the tile's id.
	 * @return Whether the tile can be passed or not. */
	public static float getDefense(int id)
	{
		float retVal = 1;
		if(terrainList[id] != null)
			retVal = terrainList[id].getDefense();
		return retVal;
	}

	/**
	 * @return whether the tile is passable.
	 */
	public boolean getPassable()
	{
		return passable;
	}

	/**
	 * @return the defense bonus
	 */
	public float getDefense()
	{
		return defense;
	}
}
