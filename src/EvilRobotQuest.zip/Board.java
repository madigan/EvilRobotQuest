import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Board extends JPanel implements KeyListener
{
	private static final int TILE_SIZE = 36;
	private static final int MAP_WIDTH = 9;
	
	private static final int MAP_X = TILE_SIZE / 2;
	private static final int MAP_Y = TILE_SIZE / 2;
	private static final int MAP_RADIUS = MAP_WIDTH / 2;
	
	private static final int NAVPAD_X = TILE_SIZE / 2;
	private static final int NAVPAD_Y = (TILE_SIZE * 10) + (TILE_SIZE / 2);
	
	private static final int TOOLBAR_X = TILE_SIZE * 4;
	private static final int TOOLBAR_Y = (TILE_SIZE * 10) + (TILE_SIZE / 2);
	
	public static int[][] map;
	public static boolean acceptInput = true;
	
	Image currentMap;
	Image character;
	Image gui;
	
	Player user;
	Person[] monsterList;
	
	public Board()
	{
		//Temporary generates random map.
		/*int mapLength = 3 * MAP_WIDTH;
		map = new int[mapLength][mapLength];
		for(int i = 0; i < map.length; i++)
		{
			for(int q = 0; q < map.length; q++)
			{
				map[i][q] = (int)Math.floor(Math.random() * 20);
			}
		}*/
		map = new int[][]  {{0, 0, 3, 13, 0},
							{0, 1, 3, 13, 0},
							{0, 0, 3, 13, 0},
							{1, 0, 4, 14, 1},
							{0, 0, 0, 1, 0}};		
		//End map generator
		
		//Temporarily selects the default map.
		currentMap = new ImageIcon(this.getClass().getResource("newTerrain.png")).getImage();
		character = new ImageIcon(this.getClass().getResource("newCharacters.png")).getImage();
		
		//Temporarily set the player up
		user = new Player("BILLEB0 B", 5, 23, 0, 0, 2, 6, 4, "CYKBOT", "ASSASIN");
		monsterList = new Player[5];
		monsterList[0] = user;
		//Get painting!
		repaint();
	}
	public void paint(Graphics g)
	{
		//Create the Graphics2D object
		Graphics2D g2d = (Graphics2D)g;
		
		//Render the interface
		//Render the map
		for(int i = 0; i < 15; i++)
		{
			g2d.setColor(new Color(i * 10, i * 10, i * 10));
			g2d.drawRect(MAP_X - i, MAP_Y - i, MAP_WIDTH * TILE_SIZE + 2 * i, MAP_WIDTH * TILE_SIZE + 2 * i);	
		}
		g2d.setColor(new Color(0));
		int srcX = 0;	//Source Coordinates
		int srcY = 0;
		int desX = 0;	//Destination Coordinates
		int desY = 0;
		for(int x = 0; x < MAP_WIDTH; x++)
		{
			for(int y = 0; y < MAP_WIDTH; y++)
			{
				//Draw the tile. This needs to be more generisized.
				desX = MAP_X + (x * TILE_SIZE);
				desY = MAP_Y + (y * TILE_SIZE);
				if((user.getX() + x - MAP_RADIUS) >= 0 && (user.getX() + x - MAP_RADIUS) < map.length && 
					(user.getY() + y - MAP_RADIUS) >= 0 && (user.getY() + y - MAP_RADIUS) < map.length)
				{
					srcX = (map[user.getX() + x - MAP_RADIUS][user.getY() + y - MAP_RADIUS] % 10) * TILE_SIZE;
					srcY = (map[user.getX() + x - MAP_RADIUS][user.getY() + y - MAP_RADIUS] / 10) * TILE_SIZE;
					g2d.drawImage(currentMap, desX, desY, desX + TILE_SIZE, desY + TILE_SIZE,
							      srcX, srcY, srcX + TILE_SIZE, srcY + TILE_SIZE, null);
				}
				else
				{
					//Paint a blank tile.
					g2d.drawImage(currentMap, desX, desY, desX + TILE_SIZE, desY + TILE_SIZE, 72, 72, TILE_SIZE, TILE_SIZE, null);
				}
			}
		}
		
		//Render the Player
		desX = (MAP_RADIUS) * TILE_SIZE + MAP_X;
		desY = (MAP_RADIUS) * TILE_SIZE + MAP_Y;
 		g2d.drawImage(character, desX, desY, desX + TILE_SIZE, desY + TILE_SIZE, 0, 36, 36, 72, null);
	}
	public void keyTyped(KeyEvent e) {} 	//Doesn't do anything.
	public void keyPressed(KeyEvent e) {} 	//Doesn't do anything.
	
	/** This method gets key input from the user, and calls the appropriate functions. */
	public void keyReleased(KeyEvent e)
	{
		acceptInput = false;
		int deltaX = 0;
		int deltaY = 0;
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_UP:
				deltaY--;
				break;
			case KeyEvent.VK_RIGHT:
				deltaX++;
				break;
			case KeyEvent.VK_DOWN:
				deltaY++;
				break;
			case KeyEvent.VK_LEFT:
				deltaX--;
				break;
		}
		user.move(deltaX, deltaY, map);
		repaint();
		acceptInput = true;
	}
	
	/** This method takes two coordinates and checks to see if there is a monster there.
	 * @return whether or not a monster is there. */
	public boolean checkForMonster(int newX, int newY)
	{
		boolean retVal = false;
		for(int i = 0; i < monsterList.length; i++)
		{
			if(map[newX][newY] == map[monsterList[i].getX()][monsterList[i].getY()])
			{
				retVal = true;
				break;
			}
		}
		return retVal;
	}
}
